// ¿Cómo acceder al primer elemento de un array? Dime 4 opciones

// ¿Cómo acceder al último elemento de un array? Dime 4 opciones

