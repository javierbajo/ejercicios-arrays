// A partir de este array:
const puntajes = [
  [10, 5, 2, 8],
  [4, 9, 3, 7],
  [6, 1, 8, 5],
];

// Crea una copia de la segunda fila del array y asignalo a una variable nueva.

// Elimina la segunda fila del array original.

// Elimina el último elemento de la primera fila del array original.

// Agrega el numero 50 al final de la tercera fila del array original.

// Eliminar el primer elemento de la tercera fila del array original.

// Agrega el numero 100 al principio de la primera fila del array original.

// Muestra por consola el array original y la copia de la segunda fila creada en el paso 2 para verificar los cambios.
